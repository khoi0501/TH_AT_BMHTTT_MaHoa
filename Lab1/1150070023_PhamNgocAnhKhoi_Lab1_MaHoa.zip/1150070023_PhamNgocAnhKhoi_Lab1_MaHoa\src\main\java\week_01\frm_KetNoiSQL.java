package week_01;

import javax.swing.*;
import java.awt.*;

public class frm_KetNoiSQL extends JFrame {

    private JTextField txt_server;
    private JTextField txt_port;
    private JTextField txt_database;
    private JTextField txt_user;
    private JPasswordField txt_password;
    private JButton btn_test;
    private JButton btn_history;
    private JLabel lbl_status;

    public frm_KetNoiSQL() {
        setTitle("Kết Nối SQL Server");
        setSize(500, 360);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel lblTitle = new JLabel("KẾT NỐI MICROSOFT SQL SERVER", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 17));
        mainPanel.add(lblTitle, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Server
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        formPanel.add(new JLabel("Server:"), gbc);
        txt_server = new JTextField("127.0.0.1", 20);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0;
        formPanel.add(txt_server, gbc);

        // Port
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        formPanel.add(new JLabel("Port:"), gbc);
        txt_port = new JTextField("1433", 10);
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1.0;
        formPanel.add(txt_port, gbc);

        // Database
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        formPanel.add(new JLabel("Database:"), gbc);
        txt_database = new JTextField("LAB1_MaHoaCoDien", 20);
        gbc.gridx = 1; gbc.gridy = 2; gbc.weightx = 1.0;
        formPanel.add(txt_database, gbc);

        // User
        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0;
        formPanel.add(new JLabel("User:"), gbc);
        txt_user = new JTextField("lab1_user", 20);
        gbc.gridx = 1; gbc.gridy = 3; gbc.weightx = 1.0;
        formPanel.add(txt_user, gbc);

        // Password
        gbc.gridx = 0; gbc.gridy = 4; gbc.weightx = 0;
        formPanel.add(new JLabel("Password:"), gbc);
        txt_password = new JPasswordField(20);
        gbc.gridx = 1; gbc.gridy = 4; gbc.weightx = 1.0;
        formPanel.add(txt_password, gbc);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // South Panel: Buttons and Status
        JPanel southPanel = new JPanel(new BorderLayout(5, 5));
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        btn_test = new JButton("Test Connection");
        btn_history = new JButton("Xem lịch sử");
        btnPanel.add(btn_test);
        btnPanel.add(btn_history);
        southPanel.add(btnPanel, BorderLayout.NORTH);

        lbl_status = new JLabel("<html>Chưa kết nối.</html>");
        lbl_status.setPreferredSize(new Dimension(460, 40));
        lbl_status.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));
        southPanel.add(lbl_status, BorderLayout.SOUTH);

        mainPanel.add(southPanel, BorderLayout.SOUTH);
        add(mainPanel);

        // Test connection button
        btn_test.addActionListener(e -> {
            try {
                int port = Integer.parseInt(txt_port.getText().trim());
                DbConfig.set(txt_server.getText().trim(), port, txt_database.getText().trim(),
                        txt_user.getText().trim(), txt_password.getPassword());
                lbl_status.setText("<html>" + DbConfig.test() + "</html>");
            } catch (Exception ex) {
                DbConfig.clear();
                lbl_status.setText("<html><font color='red'>Kết nối thất bại: " + ex.getMessage() + "</font></html>");
                JOptionPane.showMessageDialog(this, ex.getMessage(),
                        "Không kết nối được SQL Server", JOptionPane.ERROR_MESSAGE);
            }
        });

        // View history button
        btn_history.addActionListener(e -> new frm_LichSu().setVisible(true));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_KetNoiSQL().setVisible(true));
    }
}
