package week_01;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class frm_LichSu extends JFrame {

    private JTable tbl_history;
    private JButton btn_refresh;
    private JLabel lbl_status;

    public frm_LichSu() {
        setTitle("Lịch Sử Thao Tác");
        setSize(820, 420);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel lblTitle = new JLabel("LỊCH SỬ THAO TÁC — BẢNG DBO.HISTORY", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        mainPanel.add(lblTitle, BorderLayout.NORTH);

        tbl_history = new JTable(HistoryDao.emptyModel());
        tbl_history.setFillsViewportHeight(true);
        tbl_history.setRowHeight(22);
        JScrollPane scrollPane = new JScrollPane(tbl_history);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel southPanel = new JPanel(new BorderLayout(5, 5));
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        btn_refresh = new JButton("Tải lại");
        btnPanel.add(btn_refresh);
        southPanel.add(btnPanel, BorderLayout.WEST);

        lbl_status = new JLabel("Đang tải...");
        lbl_status.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 5));
        southPanel.add(lbl_status, BorderLayout.CENTER);

        mainPanel.add(southPanel, BorderLayout.SOUTH);
        add(mainPanel);

        btn_refresh.addActionListener(e -> loadData());

        loadData();
    }

    private void loadData() {
        try {
            tbl_history.setModel(HistoryDao.loadLatest(50));
            lbl_status.setText("Đã tải " + tbl_history.getRowCount() + " dòng mới nhất từ dbo.history.");
        } catch (SQLException ex) {
            lbl_status.setText("Lỗi đọc lịch sử: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_LichSu().setVisible(true));
    }
}
