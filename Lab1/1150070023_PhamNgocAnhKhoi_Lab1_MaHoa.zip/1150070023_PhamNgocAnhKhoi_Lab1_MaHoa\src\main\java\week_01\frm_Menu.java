package week_01;

import javax.swing.*;
import java.awt.*;

public class frm_Menu extends JFrame {

    private JButton btn_caesar;
    private JButton btn_vigenere;
    private JButton btn_railfence;
    private JButton btn_playfair;
    private JButton btn_transposition;
    private JButton btn_autokey;
    private JButton btn_tonghop;
    private JButton btn_tancong;

    public frm_Menu() {
        setTitle("Menu - Mã Hóa Cổ Điển");
        setSize(400, 420);
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel lblTitle = new JLabel("MÃ HÓA CỔ ĐIỂN", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        mainPanel.add(lblTitle, BorderLayout.NORTH);

        JPanel btnPanel = new JPanel();
        btnPanel.setLayout(new GridLayout(8, 1, 5, 8));

        btn_caesar = new JButton("1.1 Mã Caesar");
        btn_vigenere = new JButton("1.2 Mã Vigenère");
        btn_railfence = new JButton("1.3 Mã Rail Fence");
        btn_playfair = new JButton("1.4 Mã Playfair");
        btn_transposition = new JButton("1.5 Mã Hoán Vị Cột");
        btn_autokey = new JButton("1.6 Mã Autokey");
        btn_tonghop = new JButton("Nâng cao 01 - Tổng Hợp");
        btn_tancong = new JButton("Nâng cao 02 - Phân Tích");

        Dimension btnSize = new Dimension(220, 35);
        JButton[] buttons = {btn_caesar, btn_vigenere, btn_railfence, btn_playfair,
                btn_transposition, btn_autokey, btn_tonghop, btn_tancong};
        for (JButton btn : buttons) {
            btn.setPreferredSize(btnSize);
            btn.setMaximumSize(btnSize);
            btnPanel.add(btn);
        }

        JPanel centerWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER));
        centerWrapper.add(btnPanel);
        mainPanel.add(centerWrapper, BorderLayout.CENTER);

        add(mainPanel);

        btn_caesar.addActionListener(e -> new frm_Caesar().setVisible(true));
        btn_vigenere.addActionListener(e -> new frm_Vigenere().setVisible(true));
        btn_railfence.addActionListener(e -> new frm_RailFence().setVisible(true));
        btn_playfair.addActionListener(e -> new frm_Playfair().setVisible(true));
        btn_transposition.addActionListener(e -> new frm_Transposition().setVisible(true));
        btn_autokey.addActionListener(e -> new frm_AutoKey().setVisible(true));
        btn_tonghop.addActionListener(e -> new frm_TongHop().setVisible(true));
        btn_tancong.addActionListener(e -> new frm_TanCong().setVisible(true));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_Menu().setVisible(true));
    }
}
