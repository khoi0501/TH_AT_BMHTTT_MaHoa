package week_01;

import javax.swing.*;
import java.awt.*;

public class frm_Playfair extends JFrame {

    private JTextArea txt_plaintext;
    private JTextField txt_key;
    private JTextArea txt_matrix;
    private JButton btn_matrix;
    private JTextArea txt_ciphertext;
    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;
    private JLabel lbl_status;

    public frm_Playfair() {
        setTitle("Playfair Cipher");
        setSize(640, 500);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel lblTitle = new JLabel("MÃ PLAYFAIR", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        mainPanel.add(lblTitle, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Plaintext
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        centerPanel.add(new JLabel("Plaintext:"), gbc);
        txt_plaintext = new JTextArea(3, 30);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        JScrollPane spPlain = new JScrollPane(txt_plaintext);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0;
        centerPanel.add(spPlain, gbc);

        // Key
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        centerPanel.add(new JLabel("Key:"), gbc);
        JPanel keyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        txt_key = new JTextField("KEYWORD", 12);
        btn_matrix = new JButton("Generate Key Matrix");
        keyPanel.add(txt_key);
        keyPanel.add(btn_matrix);
        keyPanel.add(new JLabel("Chỉ gồm A-Z, ví dụ KEYWORD"));
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1.0;
        centerPanel.add(keyPanel, gbc);

        // Matrix
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        centerPanel.add(new JLabel("Key Matrix:"), gbc);
        txt_matrix = new JTextArea(5, 20);
        txt_matrix.setFont(new Font("Consolas", Font.PLAIN, 13));
        txt_matrix.setEditable(false);
        JScrollPane spMatrix = new JScrollPane(txt_matrix);
        gbc.gridx = 1; gbc.gridy = 2; gbc.weightx = 1.0;
        centerPanel.add(spMatrix, gbc);

        // Ciphertext
        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0;
        centerPanel.add(new JLabel("Ciphertext:"), gbc);
        txt_ciphertext = new JTextArea(3, 30);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        JScrollPane spCipher = new JScrollPane(txt_ciphertext);
        gbc.gridx = 1; gbc.gridy = 3; gbc.weightx = 1.0;
        centerPanel.add(spCipher, gbc);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        // Buttons and status
        JPanel southPanel = new JPanel(new BorderLayout(5, 5));
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 5));
        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_open = new JButton("Open Ciphertext File");
        btn_save = new JButton("Save Ciphertext File");
        btnPanel.add(btn_encrypt);
        btnPanel.add(btn_decrypt);
        btnPanel.add(btn_open);
        btnPanel.add(btn_save);
        southPanel.add(btnPanel, BorderLayout.CENTER);

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
        southPanel.add(lbl_status, BorderLayout.SOUTH);
        mainPanel.add(southPanel, BorderLayout.SOUTH);

        add(mainPanel);

        btn_matrix.addActionListener(e -> {
            try {
                txt_matrix.setText(PlayfairCipher.getKeyMatrix(txt_key.getText()));
                txt_matrix.setCaretPosition(0);
                lbl_status.setText("Đã tạo ma trận khóa 5x5 (I và J dùng chung ô).");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Khóa không hợp lệ", JOptionPane.ERROR_MESSAGE);
            }
        });

        btn_encrypt.addActionListener(e -> {
            String plaintext = txt_plaintext.getText();
            if (plaintext.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Hãy nhập plaintext trước khi mã hóa.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                String key = txt_key.getText().trim();
                String result = PlayfairCipher.encrypt(plaintext, key);
                txt_ciphertext.setText(result);
                txt_matrix.setText(PlayfairCipher.getKeyMatrix(key));
                lbl_status.setText("Đã mã hóa với khóa " + key + ".");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
            }
        });

        btn_decrypt.addActionListener(e -> {
            String ciphertext = txt_ciphertext.getText();
            if (ciphertext.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Hãy nhập ciphertext trước khi giải mã.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                String key = txt_key.getText().trim();
                String result = PlayfairCipher.decrypt(ciphertext, key);
                txt_plaintext.setText(result);
                txt_matrix.setText(PlayfairCipher.getKeyMatrix(key));
                lbl_status.setText("Đã giải mã với khóa " + key + ".");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
            }
        });

        btn_open.addActionListener(e -> {
            String path = FileTextIO.openText(this, txt_ciphertext);
            if (path != null) {
                lbl_status.setText("Đã mở tệp: " + path);
            }
        });

        btn_save.addActionListener(e -> {
            String path = FileTextIO.saveText(this, txt_ciphertext, "playfair_ciphertext.txt");
            if (path != null) {
                lbl_status.setText("Đã lưu tệp: " + path);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_Playfair().setVisible(true));
    }
}
