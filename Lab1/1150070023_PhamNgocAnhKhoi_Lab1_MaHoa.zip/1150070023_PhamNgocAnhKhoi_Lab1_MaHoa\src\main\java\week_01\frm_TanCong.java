package week_01;

import javax.swing.*;
import java.awt.*;

public class frm_TanCong extends JFrame {

    private JTextArea txt_cipher;
    private JButton btn_bruteforce;
    private JButton btn_frequency;
    private JTextField txt_known_plain;
    private JTextField txt_known_cipher;
    private JButton btn_known;
    private JTextArea txt_result;
    private JLabel lbl_status;

    public frm_TanCong() {
        setTitle("Phân Tích Mật Mã");
        setSize(700, 580);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel lblTitle = new JLabel("PHÂN TÍCH (TẤN CÔNG) MẬT MÃ CỔ ĐỂN", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        mainPanel.add(lblTitle, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Ciphertext input
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        centerPanel.add(new JLabel("Ciphertext:"), gbc);
        txt_cipher = new JTextArea(2, 30);
        txt_cipher.setLineWrap(true);
        txt_cipher.setWrapStyleWord(true);
        JScrollPane spCipher = new JScrollPane(txt_cipher);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0;
        centerPanel.add(spCipher, gbc);

        // Buttons for bruteforce & frequency
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1.0;
        JPanel pnlAttack1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
        btn_bruteforce = new JButton("Brute Force Caesar");
        btn_frequency = new JButton("Frequency Analysis");
        pnlAttack1.add(btn_bruteforce);
        pnlAttack1.add(btn_frequency);
        centerPanel.add(pnlAttack1, gbc);

        // Known Plaintext row
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        centerPanel.add(new JLabel("Known Plaintext:"), gbc);
        JPanel pnlKnown = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 2));
        pnlKnown.add(new JLabel("Bản rõ:"));
        txt_known_plain = new JTextField("HELLO", 8);
        pnlKnown.add(txt_known_plain);
        pnlKnown.add(new JLabel("Bản mã:"));
        txt_known_cipher = new JTextField("RIJVS", 8);
        pnlKnown.add(txt_known_cipher);
        btn_known = new JButton("Known Plaintext (Vigenère)");
        pnlKnown.add(btn_known);
        gbc.gridx = 1; gbc.gridy = 2; gbc.weightx = 1.0;
        centerPanel.add(pnlKnown, gbc);

        // Result output
        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        centerPanel.add(new JLabel("Kết quả:"), gbc);
        txt_result = new JTextArea(12, 35);
        txt_result.setFont(new Font("Consolas", Font.PLAIN, 12));
        txt_result.setEditable(false);
        JScrollPane spResult = new JScrollPane(txt_result);
        gbc.gridx = 1; gbc.gridy = 3; gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;
        centerPanel.add(spResult, gbc);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        // Status
        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setBorder(BorderFactory.createEmptyBorder(4, 5, 2, 0));
        mainPanel.add(lbl_status, BorderLayout.SOUTH);

        add(mainPanel);

        // Brute force Caesar
        btn_bruteforce.addActionListener(e -> {
            String cipher = txt_cipher.getText().trim();
            if (cipher.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Hãy nhập ciphertext cần vét cạn.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                txt_result.setText(AttackDemos.caesarBruteForce(cipher));
                txt_result.setCaretPosition(0);
                lbl_status.setText("Đã vét cạn 26 khóa Caesar.");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Frequency analysis
        btn_frequency.addActionListener(e -> {
            String cipher = txt_cipher.getText().trim();
            if (cipher.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Hãy nhập ciphertext cần thống kê tần suất.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                txt_result.setText(AttackDemos.frequency(cipher));
                txt_result.setCaretPosition(0);
                lbl_status.setText("Đã thống kê tần suất chữ cái.");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Known Plaintext Vigenère
        btn_known.addActionListener(e -> {
            String plain = txt_known_plain.getText().trim();
            String cipher = txt_known_cipher.getText().trim();
            if (plain.isEmpty() || cipher.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Hãy nhập cả bản rõ và bản mã đã biết.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                txt_result.setText(AttackDemos.knownPlaintext(plain, cipher));
                txt_result.setCaretPosition(0);
                lbl_status.setText("Đã tìm khóa Vigenère theo bản rõ đã biết.");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_TanCong().setVisible(true));
    }
}
