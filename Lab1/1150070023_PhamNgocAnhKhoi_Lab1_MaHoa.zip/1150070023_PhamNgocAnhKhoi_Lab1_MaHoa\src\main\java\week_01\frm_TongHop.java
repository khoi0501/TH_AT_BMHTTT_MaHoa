package week_01;

import javax.swing.*;
import java.awt.*;

public class frm_TongHop extends JFrame {

    private JComboBox<String> cbo_algorithm;
    private JLabel lbl_hint;
    private JTextArea txt_plaintext;
    private JTextField txt_key;
    private JTextArea txt_ciphertext;
    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;
    private JButton btn_sql;
    private JButton btn_history;
    private JLabel lbl_status;

    public frm_TongHop() {
        setTitle("Tổng Hợp Mã Hóa");
        setSize(680, 520);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel lblTitle = new JLabel("TỔNG HỢP 6 THUẬT TOÁN CỔ ĐỂN", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        mainPanel.add(lblTitle, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Algorithm row
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        centerPanel.add(new JLabel("Thuật toán:"), gbc);
        JPanel algPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        cbo_algorithm = new JComboBox<>(CipherTongHop.ALGORITHMS);
        lbl_hint = new JLabel("Khóa mẫu: 3");
        algPanel.add(cbo_algorithm);
        algPanel.add(lbl_hint);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0;
        centerPanel.add(algPanel, gbc);

        // Plaintext row
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        centerPanel.add(new JLabel("Plaintext:"), gbc);
        txt_plaintext = new JTextArea(3, 30);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        JScrollPane spPlain = new JScrollPane(txt_plaintext);
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1.0;
        centerPanel.add(spPlain, gbc);

        // Key row
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        centerPanel.add(new JLabel("Key:"), gbc);
        txt_key = new JTextField("3", 20);
        gbc.gridx = 1; gbc.gridy = 2; gbc.weightx = 1.0;
        centerPanel.add(txt_key, gbc);

        // Ciphertext row
        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0;
        centerPanel.add(new JLabel("Ciphertext:"), gbc);
        txt_ciphertext = new JTextArea(3, 30);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        JScrollPane spCipher = new JScrollPane(txt_ciphertext);
        gbc.gridx = 1; gbc.gridy = 3; gbc.weightx = 1.0;
        centerPanel.add(spCipher, gbc);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        // South Panel: Buttons and Status
        JPanel southPanel = new JPanel(new BorderLayout(5, 5));

        JPanel btnPanel1 = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 3));
        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_open = new JButton("Open File");
        btn_save = new JButton("Save File");
        btnPanel1.add(btn_encrypt);
        btnPanel1.add(btn_decrypt);
        btnPanel1.add(btn_open);
        btnPanel1.add(btn_save);

        JPanel btnPanel2 = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 3));
        btn_sql = new JButton("Kết nối SQL Server");
        btn_history = new JButton("Xem lịch sử");
        btnPanel2.add(btn_sql);
        btnPanel2.add(btn_history);

        JPanel allButtons = new JPanel(new GridLayout(2, 1, 0, 2));
        allButtons.add(btnPanel1);
        allButtons.add(btnPanel2);
        southPanel.add(allButtons, BorderLayout.CENTER);

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 0));
        southPanel.add(lbl_status, BorderLayout.SOUTH);

        mainPanel.add(southPanel, BorderLayout.SOUTH);
        add(mainPanel);

        // Combo box change
        cbo_algorithm.addActionListener(e -> {
            String alg = (String) cbo_algorithm.getSelectedItem();
            if (alg != null) {
                String sample = CipherTongHop.sampleKey(alg);
                txt_key.setText(sample);
                lbl_hint.setText("Khóa mẫu: " + sample);
            }
        });

        // Encrypt
        btn_encrypt.addActionListener(e -> {
            String algorithm = (String) cbo_algorithm.getSelectedItem();
            String input = txt_plaintext.getText();
            if (input.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Hãy nhập plaintext trước khi mã hóa.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                String result = CipherTongHop.encrypt(algorithm, input, txt_key.getText());
                txt_ciphertext.setText(result);
                String saved = HistoryDao.tryInsert(algorithm, "ENCRYPT", input, result);
                lbl_status.setText("Đã mã hóa " + algorithm + ". " + saved);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Decrypt
        btn_decrypt.addActionListener(e -> {
            String algorithm = (String) cbo_algorithm.getSelectedItem();
            String input = txt_ciphertext.getText();
            if (input.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Hãy nhập ciphertext trước khi giải mã.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                String result = CipherTongHop.decrypt(algorithm, input, txt_key.getText());
                txt_plaintext.setText(result);
                String saved = HistoryDao.tryInsert(algorithm, "DECRYPT", input, result);
                lbl_status.setText("Đã giải mã " + algorithm + ". " + saved);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Dữ liệu không hợp lệ", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Open
        btn_open.addActionListener(e -> {
            String path = FileTextIO.openText(this, txt_ciphertext);
            if (path != null) {
                lbl_status.setText("Đã mở tệp: " + path);
            }
        });

        // Save
        btn_save.addActionListener(e -> {
            String alg = (String) cbo_algorithm.getSelectedItem();
            String defaultName = (alg != null ? alg.toLowerCase().replace(" ", "") : "cipher") + "_ciphertext.txt";
            String path = FileTextIO.saveText(this, txt_ciphertext, defaultName);
            if (path != null) {
                lbl_status.setText("Đã lưu tệp: " + path);
            }
        });

        // SQL Connection
        btn_sql.addActionListener(e -> new frm_KetNoiSQL().setVisible(true));

        // History
        btn_history.addActionListener(e -> new frm_LichSu().setVisible(true));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new frm_TongHop().setVisible(true));
    }
}
