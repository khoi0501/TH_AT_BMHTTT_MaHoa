package week_01;

import javax.swing.*;
import javax.swing.JOptionPane;
import java.awt.*;

public class frm_Vigenere extends JFrame {

    private JTextArea txt_plaintext;
    private JTextField txt_key;
    private JTextArea txt_ciphertext;
    private JButton btn_encrypt;
    private JButton btn_decrypt;
    private JButton btn_open;
    private JButton btn_save;
    private JLabel lbl_status;

    public frm_Vigenere() {
        setTitle("Vigenere Cipher");
        setSize(620, 360);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel lblTitle = new JLabel("MÃ VIGENÈRE", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        mainPanel.add(lblTitle, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Plaintext
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        centerPanel.add(new JLabel("Plaintext:"), gbc);
        txt_plaintext = new JTextArea(3, 30);
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setWrapStyleWord(true);
        JScrollPane spPlain = new JScrollPane(txt_plaintext);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 1.0;
        centerPanel.add(spPlain, gbc);

        // Key
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0;
        centerPanel.add(new JLabel("Key:"), gbc);
        JPanel keyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        txt_key = new JTextField("KEY", 10);
        keyPanel.add(txt_key);
        keyPanel.add(new JLabel("Chỉ gồm chữ A-Z, ví dụ KEY"));
        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 1.0;
        centerPanel.add(keyPanel, gbc);

        // Ciphertext
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0;
        centerPanel.add(new JLabel("Ciphertext:"), gbc);
        txt_ciphertext = new JTextArea(3, 30);
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setWrapStyleWord(true);
        JScrollPane spCipher = new JScrollPane(txt_ciphertext);
        gbc.gridx = 1; gbc.gridy = 2; gbc.weightx = 1.0;
        centerPanel.add(spCipher, gbc);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        // Buttons and status
        JPanel southPanel = new JPanel(new BorderLayout(5, 5));
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 5));
        btn_encrypt = new JButton("Encrypt");
        btn_decrypt = new JButton("Decrypt");
        btn_open = new JButton("Open Ciphertext File");
        btn_save = new JButton("Save Ciphertext File");
        btnPanel.add(btn_encrypt);
        btnPanel.add(btn_decrypt);
        btnPanel.add(btn_open);
        btnPanel.add(btn_save);
        southPanel.add(btnPanel, BorderLayout.CENTER);

        lbl_status = new JLabel("Sẵn sàng.");
        lbl_status.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
        southPanel.add(lbl_status, BorderLayout.SOUTH);
        mainPanel.add(southPanel, BorderLayout.SOUTH);

        add(mainPanel);

        btn_encrypt.addActionListener(e -> {
            String plaintext = txt_plaintext.getText().trim();
            if (plaintext.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập plaintext.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                String key = txt_key.getText().trim();
                String result = week_01.VigenereCipher.encrypt(plaintext, key);
                txt_ciphertext.setText(result);
                lbl_status.setText("Đã mã hóa với khóa: " + key + ".");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        btn_decrypt.addActionListener(e -> {
            String ciphertext = txt_ciphertext.getText().trim();
            if (ciphertext.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập ciphertext.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                String key = txt_key.getText().trim();
                String result = week_01.VigenereCipher.decrypt(ciphertext, key);
                txt_plaintext.setText(result);
                lbl_status.setText("Đã giải mã với khóa: " + key + ".");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        });

        btn_open.addActionListener(e -> {
            String path = week_01.FileTextIO.openText(this, txt_ciphertext);
            if (path != null) lbl_status.setText("Đã mở file: " + path);
        });

        btn_save.addActionListener(e -> {
            String path = week_01.FileTextIO.saveText(this, txt_ciphertext, "vigenere_ciphertext.txt");
            if (path != null) lbl_status.setText("Đã lưu file: " + path);
        });
    }
}
